Hi
this components are free with source code.
Please let me know if u improve any of this components.
Thanks

milos.sula@oku-su.cz

Short description

Use this components for compression-decompression
audio in real time with audio codecs installed in windows.